print("EX7:")
print("A" * 10 +  "B"* 7 +  "CD" * 5+  "E" + "F"*6 + "G")
