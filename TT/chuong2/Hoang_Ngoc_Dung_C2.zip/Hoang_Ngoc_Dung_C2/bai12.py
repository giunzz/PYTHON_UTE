print('EX 12.Print a triangle like the one below')
n = 4
for i in range(n):
    for j in range(0, i + 1):
        print("*", end=" ")
    print(' ')