from random import randint

print("EX3: ")
name = "Hoang Ngoc Dung"
x = randint(1,10)
for i in range(x): print(name)