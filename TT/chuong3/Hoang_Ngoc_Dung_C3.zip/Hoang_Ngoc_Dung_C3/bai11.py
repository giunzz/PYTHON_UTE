print("EX 11:")
x = float(input(("Enter a weight in kilograms: ")))
print(round(x * 2.2 , 1))