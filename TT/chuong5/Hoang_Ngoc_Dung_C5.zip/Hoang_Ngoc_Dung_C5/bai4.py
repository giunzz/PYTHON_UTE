s = 0
for i in range(1,2001):
    if (i % 2): s += i
    else : s -= i
print("Answer: ", s)