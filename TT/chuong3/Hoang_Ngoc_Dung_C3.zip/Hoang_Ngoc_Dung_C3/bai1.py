from random import randint

print("EX1: ")
for i in range(50): print(randint(3,6), end = " ")
