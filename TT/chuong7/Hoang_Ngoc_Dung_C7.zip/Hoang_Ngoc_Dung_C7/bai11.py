num_list =[1]
for i in range(11):
    num_list = num_list + (i * [0]) + [1]
    #print((i * [0]) + [1])


print(num_list)