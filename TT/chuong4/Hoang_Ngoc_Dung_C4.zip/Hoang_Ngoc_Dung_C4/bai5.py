from random import randint

n = randint(1,10)
user = int(input("Enter a number: "))
if (user == n): print("Right")
else: print("Not")