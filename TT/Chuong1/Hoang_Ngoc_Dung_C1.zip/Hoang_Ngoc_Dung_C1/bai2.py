print('EX 2. Print a box like the one below')
print(" ".join("*"*s))
for i in range(0, 2):
    print("* "+"  "*(s-2) + "*")
print(" ".join("*"*s))
