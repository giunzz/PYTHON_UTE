num = [i for i in input ("enter the list of five number:").split()]
print('+'.join(num))