print ('EX 8')
a = int(input("Enter number1: "))
b = int(input("Enter number2: "))
c = int(input("Enter number3: "))
total = a + b + c
average = total / 3
print('The total of', a, b, c, 'is', total)
print('The average of', a, b, c, 'is', average)