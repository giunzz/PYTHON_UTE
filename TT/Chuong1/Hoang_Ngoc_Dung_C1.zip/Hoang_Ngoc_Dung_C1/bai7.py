print('EX 7')
x = float(input("Enter a weight in kiligrams: "))
print('Convert to pounds:', x*2.2)