print('EX 4. prints the result: ', end= "")
t = (512 - 282) / ( 47 * 48 + 5)
print('%.4f' % t)
