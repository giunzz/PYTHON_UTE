from random import randint

print("EX4: ")
x = randint(100,1000)/100
print(x)
