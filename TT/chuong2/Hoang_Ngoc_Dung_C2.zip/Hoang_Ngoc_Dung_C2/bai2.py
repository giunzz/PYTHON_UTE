print("EX2: ")
print(" Hoang Ngoc Dung " * 100)