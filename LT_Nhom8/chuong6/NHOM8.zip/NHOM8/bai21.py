s1 = input("Enter a string: ")
s2 = input("Enter a string want to replace: ")
new_string = s1.replace(s1, s2)
print("New string: ", new_string)