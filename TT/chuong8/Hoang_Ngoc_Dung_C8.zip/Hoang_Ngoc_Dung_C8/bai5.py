import random

a = ["Nothing is impossible, the word itself says ‘I’m possible.","Here comes the sun. And I say, it’s all right.","Do your thing and don't care if they like it"]

print(random.choice(a))