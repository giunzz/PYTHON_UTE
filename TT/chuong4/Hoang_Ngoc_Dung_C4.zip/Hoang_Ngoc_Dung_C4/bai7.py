s1 = float(input("Enter the first side: "))
s2 = float(input("Enter the second side: "))
if (abs(s1 - s2) == 0.001) : print("Close")
else: print("Not close")
