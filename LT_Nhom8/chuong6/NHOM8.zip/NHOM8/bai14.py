n = input("Enter the day in format (dd/mm/yyyy): ")
n = n.replace("/", '-')
print(n)