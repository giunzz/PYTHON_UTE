#exercise 10
def in2chu():
    n = input("Enter a string: ")
    for char in n:
        print(char * 2)

if __name__ == "__main__":
    in2chu()
