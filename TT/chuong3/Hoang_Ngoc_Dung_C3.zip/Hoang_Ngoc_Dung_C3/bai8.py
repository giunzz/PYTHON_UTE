print("EX8: ")
minute = int(input("Enter number of seconds: "))
print(minute, " seconds is ", minute // 60, " minutes and ", minute % 60, " seconds")
