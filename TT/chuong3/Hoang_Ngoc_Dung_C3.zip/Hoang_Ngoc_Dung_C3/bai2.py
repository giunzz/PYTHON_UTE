from random import randint

print("EX2: ")
x = randint(1,50)
y = randint(2,5)
print(pow(x, y))