L = [8,9,10]
L[1] = 17 #Set the second entry (index 1) to 17
L.extend([4, 5, 6]) # Add 4, 5, and 6 to the end of the list
L.pop(0) #Remove the first entry from the list
L.sort() # Sort the list
L = L * 2 # Double the list
L.insert(3, 25) # Insert 25 at index 3