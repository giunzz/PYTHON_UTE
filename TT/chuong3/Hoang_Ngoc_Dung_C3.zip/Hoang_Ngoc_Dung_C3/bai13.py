print("EX 13:")
import math
n = int(input("Enter the number : " ))
print("Sine of ", n, " is ", round(math.sin(n)))
print("Cosine of ", n, " is ", round(math.cos(n)))
print("Tangent of ", n, " is ", round(math.tan(n)))