print('EX 10. Print a box like the one below')
s = 19
for i in range(4):
    print(" ".join("*"*s))
