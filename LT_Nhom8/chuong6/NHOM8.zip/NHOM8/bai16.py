bi = input("Enter a binary number: ")
decimal = int(bi,2)
print("Decimal", decimal)