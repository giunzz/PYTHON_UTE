print("EX6:\r")
for i in range(100, 0,-2):
    print(i,end = " ")
print()