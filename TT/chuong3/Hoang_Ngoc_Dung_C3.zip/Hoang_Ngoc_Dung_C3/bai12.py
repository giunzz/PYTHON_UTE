
print("EX 12:")
n = int(input("Enter the number : " ))
t = 1
for i in range(1,n + 1):
    t *= i
print("The factorial of ", n, " is ", t)
