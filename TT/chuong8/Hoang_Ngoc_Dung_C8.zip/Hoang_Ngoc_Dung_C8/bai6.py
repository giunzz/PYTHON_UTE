import random 
number = random.sample(range(1,49),6)
print("A simple lottery number!!")
print('Number: ', number)