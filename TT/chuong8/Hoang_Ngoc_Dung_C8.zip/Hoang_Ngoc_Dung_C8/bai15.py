L = [j for i in range(11) for j in [1, *([0]*i)]]
print(L)
