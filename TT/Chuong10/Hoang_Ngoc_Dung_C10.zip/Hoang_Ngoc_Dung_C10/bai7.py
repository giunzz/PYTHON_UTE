list_ = []
for i in range(100):
    list_.append('1'*i)
print(list_)