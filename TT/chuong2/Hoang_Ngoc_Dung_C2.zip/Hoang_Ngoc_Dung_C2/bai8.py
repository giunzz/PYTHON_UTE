print("EX8:")
name = (input("Enter your name: "))
times = int(input("How many times to print it: "))
for i in range(times):
    print(name)