print("EX 14:")
import math
x = int(input("Enter an angle in degrees: "))
print("The sine of ", x, " is ", round(math.sin(math.radians(x)), 2))
