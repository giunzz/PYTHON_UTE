s1 = int(input("Enter the first side: "))
s2 = int(input("Enter the second side: "))
s1,s2 = s2,s1
print("Swap: ", s1 , "," , s2)