   
duplicate = [2, 4, 10, 20, 5, 2, 20, 4,5]
print(list(set(duplicate)))
