s = input("enter a string : ")
i = 0
while i < len((s)):
    print(s[i])
    i += 1
s_1 = s.split() 
print(s_1)   
j = 0
n = 0
while j < len(s_1[1]):
    print(s_1[1][n])
    n += 1
    j += 1