word = input(" enter a word :")
word.lower()
word_sorted = ' '.join(sorted(word))
print(f'The word with letters rearranged alphabetically:{word_sorted}')