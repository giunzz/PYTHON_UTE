s1 = input("Enter a string1: ")
s2 = input("Enter a string2: ")
print("".join([s1, s2]))
