import math
num = int(input("Enter a number:"))
print(f"{num:,d}")
