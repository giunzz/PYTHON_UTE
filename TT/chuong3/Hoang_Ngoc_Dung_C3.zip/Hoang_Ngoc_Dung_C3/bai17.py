print("EX 17:")
import calendar
Y = int(input("Enter a year: "))
print("A year is a leap year: ", calendar.isleap(Y))
