def root(x, n=2):
    print(x**(1/n))

root(27,3)


