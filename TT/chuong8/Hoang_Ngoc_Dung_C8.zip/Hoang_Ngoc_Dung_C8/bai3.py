s = input("Enter a sentence :")
s= s.split()
t3 = s[2]
print(t3)
for j in range(len(t3)): print(t3[j], end =" ")
 