s = input("Enter a string: ")
stripped_string = s.strip() 
print(stripped_string) 