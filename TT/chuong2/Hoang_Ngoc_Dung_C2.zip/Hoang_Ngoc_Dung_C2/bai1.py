print("EX1: ")
print(" Hoang Ngoc Dung \n" * 100)