number_list=[i for i in range(3,100,3)]
print(number_list)
