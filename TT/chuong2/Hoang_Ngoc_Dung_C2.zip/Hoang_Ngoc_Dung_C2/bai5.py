print("EX5: ")
for i in range(8, 90,3):
    print(i,end = " ")
print("")