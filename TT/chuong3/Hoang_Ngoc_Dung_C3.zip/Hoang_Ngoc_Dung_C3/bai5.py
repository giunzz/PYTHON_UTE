from random import randint

print("EX5: ")
for i in range(2,52):
    print(randint(1,i), end =" ")