i = 1
while i<51:
  print(i)
  i += 1
