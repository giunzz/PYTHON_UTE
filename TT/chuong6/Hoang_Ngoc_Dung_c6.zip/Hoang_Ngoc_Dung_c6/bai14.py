#exercise 14
def name():
    ten = input("Nhập tên của bạn dưới dạng chữ thường: ")
    capitalize = ten.title()
    print("Tên sau khi được chuyển đổi:",capitalize)

if __name__ == "__main__":
    name()
