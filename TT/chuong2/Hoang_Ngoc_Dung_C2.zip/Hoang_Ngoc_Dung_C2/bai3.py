print("EX3: ")
for i in range(1,101):
    print(i , " Hoang Ngoc Dung")