weight = float(input('enter weight in the kilograms: '))
weight_converted = weight * 2.2046
print(f'Your weight in the pounds is {weight_converted: .1f}.')