print('EX 9')
bill = float(input("Enter the amount of a meal: "))
tip = float('Percent tip')
t = bill * tip / 100
print('The tip is: ', t, 'The total amount is: ', bill + t)