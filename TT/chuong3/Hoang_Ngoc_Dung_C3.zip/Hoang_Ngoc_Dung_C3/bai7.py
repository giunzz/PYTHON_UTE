print("EX7: ")
n = float(input("Enter an angle between -180 and 180: "))
n %= 360
print("Covert angle to 0 and 360: ", n)