print('EX 5')
x = int(input("Enter a number: "))
print('The square of', x, 'is', str(x*x) + '.', sep=" ")
